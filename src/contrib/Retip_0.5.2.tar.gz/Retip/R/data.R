#' FiehnHilic positive dataset.
#'
#' @docType data
#'
#' @usage data(HILIC)
#'
#'
#' @keywords datasets Fiehn Lab Hilic
#'
#' @references you have to chose one reference
#'
#' @source \href{http://mona.fiehnlab.ucdavis.edu/}{QTL Archive}
#'
#' @examples
#' data(HILIC)

"HILIC"

