## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(Retip)

## ----echo=FALSE----------------------------------------------------------

knitr::include_graphics("Rerip_logo.png")


## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(HILIC,5))

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  library(Retip)
#  
#  #>Starts parallel computing
#  prep.wizard()
#  
#  #>import excel file with mandatory field
#  
#  RP <- readxl::read_excel("Riken_PlaSMA_RP.xlsx", col_types = c("text",
#                                                "text", "text", "numeric"))
#  
#  #> or use HILIC database included
#  HILIC <- HILIC
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> Calculate Chemical Descriptors from CDK
#  descs <- getCD(HILIC)
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> Clean dataset from NA and low variance value
#  db_rt <- proc.data(descs)
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> Plot chem space, the first value is your library with Chemical descriptors calculated,
#  #> the second one is your target that can be a included database
#  #> or your favourite one that you have uploaded inside Retip
#  
#  chem.space(db_rt,t="HMDB")
#  

## ----echo=FALSE----------------------------------------------------------

knitr::include_graphics("chemspace.jpeg")


## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #>################ Options center and scale data  ####################################
#  
#  #> this option improves Keras model
#  
#  preProc <- cesc(db_rt) #Build a model to use for center and scale a dataframe
#  db_rt <- predict(preProc,db_rt) # use the above created model for center and scale dataframe
#  
#  #> IMPORTANT : if you use this option remember to set cesc variable
#  #> #########   into rt.spell and getRT.smile functions
#  
#  #>#####################################################################################
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> Split in training and testing using caret::createDataPartition
#  set.seed(101)
#  inTraining <- caret::createDataPartition(db_rt$XLogP, p = .8, list = FALSE)
#  training <- db_rt[ inTraining,]
#  testing  <- db_rt[-inTraining,]
#  
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> Train Model
#  
#  xgb <- fit.xgboost(training)
#  
#  rf  <- fit.rf(training)
#  
#  brnn <- fit.brnn(training)
#  
#  keras <- fit.keras(training,testing)
#  
#  lightgbm <- fit.lightgbm(training,testing)
#  
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> save an RF, XGBOOST, BRNN, LIGHTGBM models
#  saveRDS(lightgbm, "light_plasma.rds")
#  #> load
#  light_plasma <- readRDS("light_plasma.rds")
#  
#  
#  #> save or load keras model
#  save_model_hdf5(keras1,filepath = "keras_HI")
#  #> load
#  keras_HI <- load_model_hdf5("keras_HI")
#  
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> first you have to put the testing daframe and then the name of the models you have computed
#  stat <- get.score(testing,xgb,rf,brnn,keras,lightgbm)
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> first you have to put the testing daframe and then the name of the models you want to visualize.
#  #> Last value is the title of the graphics.
#  p.model(testing, m=brnn,title = "  RIKEN PLASMA")
#  

## ----echo=FALSE----------------------------------------------------------

knitr::include_graphics("error_hilic.jpeg")
knitr::include_graphics("pred_real_hilic.jpeg")


## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> import dataset
#  
#  pathogen_box <- readxl::read_excel("pathogen_box_hilic_rt.xlsx", col_types = c("text",
#                                                                 "text", "text"))
#  #> compute Chemical descriptors
#  pathogen_box_desc <- getCD(pathogen_box)
#  
#  #> perform the RT spell
#  pathogen_box_pred <- RT.spell(training,pathogen_box_desc,model=keras)
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  
#  db_mona <- prep.mona(msp="MoNA-export-CASMI_2016.msp")
#  
#  mona <- getCD(db_mona)
#  
#  mona_rt <- RT.spell(training,mona,model=keras_HI)
#  
#  addRT.mona(msp="MoNA-export-CASMI_2016.msp",mona_rt)
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> example of Human Metabolome database predicted
#  
#  hmdb_pred <- RT.spell(training,target="HMBD",model=keras,cesc=cesc)
#  
#  #> You have only to use cesc function if you have used on retention time library before
#  

## ---- collapse = TRUE, comment = "#>",eval = FALSE-----------------------
#  
#  #> export example for MSFINDER in positive polarity
#  
#  RT.export(prediction,program="MSFINDER",pol = "pos")
#  
#  

